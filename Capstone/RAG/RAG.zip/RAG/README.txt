RAG Chatbot

A Retrieval-Augmented Generation (RAG) chatbot that answers questions from uploaded PDF documents.

Requirements
- Python 3.14
- Ollama

Setup

1. Install the required Python packages:
pip install -r requirements.txt

2. Download the Qwen model:
ollama pull qwen3:8b

3. Start Ollama.

4. Run the application:
streamlit run app.py

5. Upload any PDF and start asking questions.